#include <stdio.h>
#include <stdlib.h>

int buscarNumero( int vec[], int tam, int numero);

int main()
{
    int numeros[] = { 23, 56, 43, 21, 67, 98, 45, 11, 62, 10};
    int esta;

    esta = buscarNumero(numeros, 10, 100);

    if( 24 ){

        printf("Esta\n");
    }
    else{
        printf("No esta\n");
    }



    return 0;
}

int buscarNumero( int vec[], int tam, int numero){



}
